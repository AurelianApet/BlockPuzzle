﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Ultimate Mobile - InAppPurchases")]

	public class UM_CheckBillingConnectState : FsmStateAction {

		public FsmEvent BillingStateConnecetd;
		public FsmEvent BillingStateDisconnecetd;


		public override void Reset() {
			
		}		
		
		public override void OnEnter() {

			if(UM_InAppPurchaseManager.instance.IsInited) {
				Fsm.Event(BillingStateConnecetd);
			} else {
				Fsm.Event(BillingStateDisconnecetd);
			}

			Finish();
		}
	}
}
