﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("Ultimate Mobile - InAppPurchases")]
	[Tooltip("Action will start purchase flow on device. In Editor mode Success event will fired immediately")]
	public class UM_IsProductPurchased : FsmStateAction {

		[RequiredField]
		public FsmString productIdentifier;
		
		[ActionSection("Result")]

		[UIHint(UIHint.Variable)]
		public FsmBool isPurchased;
		
		public FsmEvent ProductStatePurchased;
		public FsmEvent ProductStateUnknown;


		public override void Reset() {
			productIdentifier = null;
			isPurchased = null;
			ProductStatePurchased = null;
			ProductStateUnknown = null;
		}
		
		
		public override void OnEnter() {

			isPurchased.Value = UM_InAppPurchaseManager.instance.IsProductPurchased(productIdentifier.Value);
			Debug.Log(productIdentifier.Value);
			if(isPurchased.Value) {

				Debug.Log("Purchased");
				Fsm.Event(ProductStatePurchased);
			} else {
				Debug.Log("No Purchased");
				Fsm.Event(ProductStateUnknown);
			}
			Finish();
			
			
		}

	}
}
