﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("WP8 Native  - Pop-ups")]
	public class WPN_RatePopup : FsmStateAction {
		
		public FsmString title; 	
		public FsmString message;   

		public FsmEvent yesEvent;
		public FsmEvent noEvent;

		[Tooltip("Result will be fired in unity Editor")]
		public WP8DialogResult ResultInEditor = WP8DialogResult.RATED;

		private WP8RateUsPopUp rate;
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				ParseResult(ResultInEditor);
				return;
			}


			WP8RateUsPopUp rate = WP8RateUsPopUp.Create(title.Value, message.Value);


			WP8RateUsPopUp.OnComplete += onRatePopUpClose;

			
		}

		public override void Reset() {
			base.Reset();

			title =  "Dialog title";
			message   = "Dialog message";

			
		}



		private void onRatePopUpClose(WP8DialogResult res) {
			
			//removing listner
			WP8RateUsPopUp.OnComplete -= onRatePopUpClose;
		
			
			//parsing result
			ParseResult(res);
		}


		private void ParseResult(WP8DialogResult res) {
			switch(res) {
			case WP8DialogResult.RATED:
				Fsm.Event(yesEvent);
				break;
			case WP8DialogResult.DECLINED:
				Fsm.Event(noEvent);
				break;
			}
			
			Finish();
		}
		
	}
}


