using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {

	[ActionCategory("WP8 Native - Billing")]
	[Tooltip("Action will start purchase flow on device. In Editor mode Success event will fired immediately")]
	public class WPN_Purchase : FsmStateAction {


		[Tooltip("Event fired when Store Kit initlization is complete")]
		public FsmEvent successEvent;

		[Tooltip("Event fired when Store Kit initlization is failed")]
		public FsmEvent failEvent;


		[Tooltip("Purhase product Id")]
		public FsmString ProductID  = "";

	

		public override void OnEnter() {

			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			


			WP8InAppPurchasesManager.OnPurchaseFinished += OnProductPurchased;
			WP8InAppPurchasesManager.instance.purchase(ProductID.Value);
			
		}

		private void OnProductPurchased(WP8PurchseResponce result) {
			if(result.IsSuccses) {
				OnPurchase();
			} else {
				OnFailed();
			}

		}




		private void OnPurchase() {
			WP8InAppPurchasesManager.OnPurchaseFinished -= OnProductPurchased;

			Fsm.Event(successEvent);
			Finish();

		}

		private void OnFailed() {
			WP8InAppPurchasesManager.OnPurchaseFinished -= OnProductPurchased;

			Fsm.Event(failEvent);
			Finish();

		}
		
	}
}
