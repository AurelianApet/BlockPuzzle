﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Google Analytics")]
	public class GA_PageHit : FsmStateAction {


		public FsmString host;
		public FsmString page;
		public FsmString title;
		public FsmString description;
		public FsmString linkId ;


		public override void OnEnter() {
			GoogleAnalytics.Client.SendPageHit(host.Value, page.Value, title.Value, description.Value, linkId.Value);
			Finish();

		}

		
	}
}
