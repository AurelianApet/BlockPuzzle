﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Google Analytics")]
	public class GA_TransactionHit : FsmStateAction {


		public FsmString id;
		public FsmString affiliation;
		public FsmString currencyCode;
		public FsmFloat revenue;
		public FsmFloat shipping;
		public FsmFloat tax;


		public override void OnEnter() {
			GoogleAnalytics.Client.SendTransactionHit(id.Value, affiliation.Value, currencyCode.Value, revenue.Value, shipping.Value, tax.Value);
			Finish();

		}

		
	}
}
