﻿////////////////////////////////////////////////////////////////////////////////
//  
// @module Android Native Plugin for Unity3D 
// @author Osipov Stanislav (Stan's Assets) 
// @support stans.assets@gmail.com 
//
////////////////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Collections;



namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Google Analytics")]
	public class GA_ItemHit : FsmStateAction {


		public FsmString transactionId;
		public FsmString name;
		public FsmString SKU;
		public FsmFloat price;
		public FsmInt quantity;
		public FsmString category;
		public FsmString currencyCode;


		public override void OnEnter() {
			GoogleAnalytics.Client.SendItemHit(transactionId.Value, name.Value, SKU.Value, price.Value, quantity.Value, category.Value, currencyCode.Value);
			Finish();

		}

		
	}
}
